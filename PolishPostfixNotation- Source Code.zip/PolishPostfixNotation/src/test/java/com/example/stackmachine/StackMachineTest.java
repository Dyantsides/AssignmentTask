
package com.example.stackmachine;

import com.programming.stackmachine.Node;
import com.programming.stackmachine.StackMachineExecutor;
import com.programming.stackmachine.StackMachineImpl;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class StackMachineTest {
    @Test
    public void pushAndPopOperationTest() {
        StackMachineImpl stackMachineImpl = getStackMachineImpl();
        final Double value1 = 2.5;
        final Double value2 = -3.5;
        stackMachineImpl.push(value1);
        stackMachineImpl.push(value2);
        stackMachineImpl.pop();
        Double actualOutput = stackMachineImpl.getHead().getValue();
        assertEquals(value1, actualOutput);
    }

    @Test
    public void AddOperationTest() {
        StackMachineImpl stackMachineImpl = getStackMachineImpl();
        final Double value1 = 2.5;
        final Double value2 = -3.5;
        stackMachineImpl.push(value1);
        stackMachineImpl.push(value2);
        stackMachineImpl.add();
        final Double expectedValue = value1 + value2;
        final Double actualoutput = stackMachineImpl.getHead().getValue();
        assertEquals(expectedValue, actualoutput);
    }

    @Test
    public void multiplyOperationTest() {
        StackMachineImpl stackMachineImpl = getStackMachineImpl();
        final Double value1 = 2.5;
        final Double value2 = -3.5;
        stackMachineImpl.push(value1);
        stackMachineImpl.push(value2);
        stackMachineImpl.multiply();
        final Double expectedValue = value1 * value2;
        final Double actualoutput = stackMachineImpl.getHead().getValue();
        assertEquals(expectedValue, actualoutput);
    }

    @Test
    public void negateOperationTest() {
        StackMachineImpl stackMachineImpl = getStackMachineImpl();
        final Double value1 = 2.5;
        final Double value2 = -3.5;
        stackMachineImpl.push(value1);
        stackMachineImpl.push(value2);
        stackMachineImpl.negate();
        final Double negateValue = -1.0;
        final Double expectedValue = value2 * negateValue;
        final Double actualOutput = stackMachineImpl.getHead().getValue();
        assertEquals(expectedValue, actualOutput);
    }

    @Test
    public void invertOperationTest() {
        StackMachineImpl stackMachineImpl = getStackMachineImpl();
        final Double value1 = 2.5;
        final Double value2 = -3.5;
        stackMachineImpl.push(value1);
        stackMachineImpl.push(value2);
        stackMachineImpl.invert();
        final Double invertValue = 1.0;
        final Double expectedValue = invertValue / value2;
        final Double actualOutput = stackMachineImpl.getHead().getValue();
        assertEquals(expectedValue, actualOutput);
    }

    @Test
    public void undoOperationTest() {
        StackMachineImpl stackMachineImpl = getStackMachineImpl();
        final Double value1 = 2.5;
        final Double value2 = 3.5;
        stackMachineImpl.push(value1);
        stackMachineImpl.push(value2);
        stackMachineImpl.add();
        stackMachineImpl.undo();
        final Double actualOutput = stackMachineImpl.getHead().getValue();
        assertEquals(value2, actualOutput);
    }

    @Test
    public void clearOperationTest() {
        StackMachineImpl stackMachineImpl = getStackMachineImpl();
        final Double value1 = 2.5;
        final Double value2 = 3.5;
        stackMachineImpl.push(value1);
        stackMachineImpl.push(value2);
        stackMachineImpl.add();
        stackMachineImpl.clear();
        Node actualOutput = stackMachineImpl.getHead();
        assertEquals(null, actualOutput);
    }

    /*@Test
    public void executeMethodTest(){
        StackMachineExecutor stackMachineExecutor = new StackMachineExecutor();
        Scanner scanner = new Scanner(System.in);
        stackMachineExecutor.setReader(scanner);
        StackMachineImpl stackMachineImpl = getStackMachineImpl();
        Node actualOutput = stackMachineImpl.getHead();
        assertEquals(null, actualOutput);
    }*/

    /**
     * Test for incorrect input
     */
    @Test
    public void incorrectInputOperationTest() {
        //TODO:Need to test this method for invalid input
    }

    private StackMachineImpl getStackMachineImpl() {
        return new StackMachineImpl();
    }
}


package com.programming.stackmachine;

/**
 * Below enums denotes all operation types user can perform on the stack
 */
public enum OperationType {
    PUSH("PUSH"),
    POP("POP"),
    CLEAR("CLEAR"),
    ADD("ADD"),
    MUL("MUL"),
    NEG("NEG"),
    INV("INV"),
    UNDO("UNDO"),
    PRINT("PRINT"),
    QUIT("QUIT");

    private String val;

    /**
     * constructor
     *
     * @param val
     */
    OperationType(final String val) {
        this.val = val;
    }

    /**
     * Getter to access the private class property.
     *
     * @return
     */
    public String getValue() {
        return this.val;
    }
}

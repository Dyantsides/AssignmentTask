package com.programming.stackmachine;

/**
 * Node of a linked list to be used for the stack operation.
 */
public class Node {
    private Double value;
    private Node next;

    /**
     * Node Constructor
     */
    Node() {
        this.value = null;
        this.next = null;
    }

    /**
     * Getter to access the private value property of the node
     *
     * @return
     */
    public Double getValue() {
        return value;
    }

    /**
     * Setter to set the value property of the node
     *
     * @param value
     */
    public void setValue(Double value) {
        this.value = value;
    }

    /**
     * Getter to access the private next node pointer property of the node
     *
     * @return
     */
    public Node getNext() {
        return next;
    }

    /**
     * Setter for the next node pointer property of the node
     *
     * @param next
     */
    public void setNext(Node next) {
        this.next = next;
    }
}

package com.programming.stackmachine;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Main class for the application
 */
public class StackMachineMain {
    public static void main(String args[]) throws IOException {
        StackMachineExecutor stackMachineExecutor = new StackMachineExecutor();
        Scanner scanner = new Scanner(System.in);
        stackMachineExecutor.setReader(scanner);
        stackMachineExecutor.execute();
    }
}

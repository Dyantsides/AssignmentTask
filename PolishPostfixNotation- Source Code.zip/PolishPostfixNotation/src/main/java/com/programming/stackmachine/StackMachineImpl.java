package com.programming.stackmachine;

import com.programming.stackmachine.OperationType;

/**
 * This class implements all stack operations.
 * This is a singly linked list implementation of the stack.
 */
public class StackMachineImpl {
    //private static final Logger LOG = LoggerFactory.getLogger(KocabCryptoSettingsServiceImpl.class);
    private Node head;
    private Node node;
    private OperationStack operationStack;

    /**
     * Constructor to create an initial empty stack using Node class
     */
    public StackMachineImpl() {
        this.head = null;
        this.node = null;
        this.operationStack = new OperationStack();
    }

    /**
     * returns the top element of the stack
     *
     * @return
     */
    public Node getHead() {
        return head;
    }

    /**
     * set the top element of the stack
     *
     * @param head
     */
    public void setHead(Node head) {
        this.head = head;
    }

    /**
     * retuns the current node
     *
     * @return
     */
    public Node getNode() {
        return node;
    }

    /**
     * set the current node
     *
     * @param node
     */
    public void setNode(Node node) {
        this.node = node;
    }

    /**
     * Returns the object of OperationStack class
     *
     * @return
     */
    public OperationStack getOperationStack() {
        return operationStack;
    }

    /**
     * Set the object of OperationStack class
     *
     * @param operationStack
     */
    public void setOperationStack(OperationStack operationStack) {
        this.operationStack = operationStack;
    }

    /**
     * Accept the valid decimal input and push the value on top of the stack
     *
     * @param input
     */
    public void push(Double input) {
        node = new Node();
        node.setValue(input);
        if (head != null) {
            node.setNext(head);
        }
        head = node;
        node = null;
        this.operationStack.push(new StackMachineState(OperationType.PUSH, input));
    }

    /**
     * Remove the top element from the stack
     */
    public Double pop() {
        if (this.isEmpty()) {
            System.out.println(ApplicationConstants.EMPTY_STACK);
            return null;
        }
        final Double data = head.getValue();
        node = head.getNext();
        head.setNext(null);
        head = node;
        return data;
    }

    /**
     * Remove all elements from the stack
     */
    public void clear() {
        this.operationStack.push(new StackMachineState(OperationType.CLEAR, head));
        head = null;
    }

    /**
     * Adds the top two elements on the stack and pushes the result back to the stack
     */
    public void add() {
        if (!this.isEmpty()) {
            if (head.getNext() != null) {
                Double value1 = this.pop();//value1 is top element value
                Double value2 = this.pop();
                push(value1 + value2);
                this.operationStack.push(new StackMachineState(OperationType.ADD, value1, value2));
            } else {
                //TODO:need to log an error here instead of printing
                System.out.println(ApplicationConstants.OPERATION_NOT_POSSIBLE_DUE_TO_STACK_SIZE);
                return;
            }
        } else {
            //TODO:need to log an error here instead of printing
            System.out.println(ApplicationConstants.EMPTY_STACK);
        }
    }

    /**
     * Multiplies the top two elements on the stack and pushes the result back to the stack
     */
    public void multiply() {
        if (!this.isEmpty()) {
            if (head.getNext() != null) {
                Double value1 = this.pop();//value1 is top element value
                Double value2 = this.pop();
                this.push(value1 * value2);
                this.operationStack.push(new StackMachineState(OperationType.MUL, value1, value2));
            } else {
                //TODO:need to log an error here instead of printing
                System.out.println(ApplicationConstants.OPERATION_NOT_POSSIBLE_DUE_TO_STACK_SIZE);
            }
        } else {
            //TODO:need to log an error here instead of printing
            System.out.println(ApplicationConstants.EMPTY_STACK);
        }
    }

    /**
     * Negates the top element on the stack and pushes the result back to the stack
     */
    public void negate() {
        if (!this.isEmpty()) {
            Double value = this.pop();
            this.push(value * ApplicationConstants.NEGATE_VALUE);
            this.operationStack.push(new StackMachineState(OperationType.NEG, value));
        } else {
            System.out.println(ApplicationConstants.EMPTY_STACK);
        }
    }

    /**
     * Negates the top element on the stack and pushes the result back to the stack
     */
    public void invert() {
        if (!this.isEmpty()) {
            Double value = this.pop();
            this.push(ApplicationConstants.INVERT_VALUE / value);
            this.operationStack.push(new StackMachineState(OperationType.INV, value));
        } else {
            //TODO:need to log an error here instead of printing
            System.out.println(ApplicationConstants.EMPTY_STACK);
        }
    }

    /**
     * Undo the top element on the stack and pushes the result back to the stack
     */
    public void undo() {
        if (this.operationStack.isEmpty()) {
            System.out.println(ApplicationConstants.OPERATION_STACK_EMPTY_STACK);
            return;
        }
        final StackMachineState operationStackNode = this.operationStack.pop();
        switch (operationStackNode.getOperation()) {
            case PUSH:
                this.pop();
                break;
            case POP:
                this.push(operationStackNode.getValue1());
                break;
            case CLEAR:
                this.head = operationStackNode.getHead();
                break;
            case ADD:
                this.pop();
                this.push(operationStackNode.getValue2());
                this.push(operationStackNode.getValue1());
                break;
            case MUL:
                this.pop();
                this.push(operationStackNode.getValue2());
                this.push(operationStackNode.getValue1());
                break;
            case NEG:
                this.pop();
                this.push(operationStackNode.getValue1());
                break;
            case INV:
                this.pop();
                this.push(operationStackNode.getValue1());
                break;
            default:
                break;
        }
    }

    /**
     * Print all elements on the stack
     */
    public void print() {
        if (!this.isEmpty()) {
            node = head;
            while (node != null) {
                System.out.println(node.getValue());
                node = node.getNext();
            }
        } else {
            //TODO:need to log an error here instead of printing
            System.out.println(ApplicationConstants.EMPTY_STACK);
        }
    }

    /**
     * Utility method to check if stack is empty
     *
     * @return
     */
    private boolean isEmpty() {
        return (head == null);

    }

}

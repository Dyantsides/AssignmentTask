package com.programming.stackmachine;

import java.util.Stack;

/**
 * This class maintains a stack that holds objects of the StackStateMachine class.
 * This is the main class for UNDO operation.
 */
public class OperationStack {
    private Stack<StackMachineState> stack;

    /**
     * Constructor
     */
    public OperationStack() {
        this.stack = new Stack<StackMachineState>();
    }

    /**
     * Push method to move the latest object on top of the stack.
     *
     * @param operationNode
     */
    public void push(final StackMachineState operationNode) {
        this.stack.push(operationNode);
    }

    /**
     * Pop method to pop the top object from the class.
     *
     * @return
     */
    public StackMachineState pop() {
        if (this.stack.isEmpty()) {
            System.out.println(ApplicationConstants.OPERATION_STACK_EMPTY_STACK);
            return null;
        }
        return this.stack.pop();
    }

    /**
     * Util method to check if the stack is empty.
     *
     * @return
     */
    public boolean isEmpty() {
        return this.stack.isEmpty();
    }
}

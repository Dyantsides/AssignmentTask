package com.programming.stackmachine;

import com.programming.stackmachine.OperationType;

/**
 * This class holds the current state of the latest operation performed on the StackMachine
 * to be later used for UNDO operation.
 */
public class StackMachineState {
    private OperationType operationType;
    private Double value1;
    private Double value2;
    private Node head;

    /**
     * Constructor to be used for operations like ADD, MUL where two values(N) are needed.
     *
     * @param operation
     * @param value1
     * @param value2
     */
    StackMachineState(OperationType operation, Double value1, Double value2) {
        this.operationType = operation;
        this.value1 = value1;
        this.value2 = value2;
    }

    /**
     * Constructor to be used for operations like PUSH, POP, INVERT etc where one value(N) is needed.
     *
     * @param operation
     * @param value1
     */
    StackMachineState(OperationType operation, Double value1) {
        this.operationType = operation;
        this.value1 = value1;
    }

    /**
     * Constructor to be used for CLEAR operation where top position need to be maintained in case of UNDO operation
     *
     * @param operation
     * @param head
     */
    StackMachineState(OperationType operation, Node head) {
        this.operationType = operation;
        this.head = head;
    }

    /**
     * Getter for top of the stack
     *
     * @return
     */
    public Node getHead() {
        return head;
    }

    /**
     * Setter for top of the stack
     *
     * @param head
     */
    public void setHead(Node head) {
        this.head = head;
    }

    /**
     * Getter to return operation type performed i.e. ADD, MUL etc
     *
     * @return
     */
    public OperationType getOperation() {
        return operationType;
    }

    /**
     * Setter for the operation type
     *
     * @param operation
     */
    public void setOperation(OperationType operation) {
        this.operationType = operation;
    }

    /**
     * Getter for the value of the operation
     *
     * @return
     */
    public Double getValue1() {
        return value1;
    }

    /**
     * Setter for the value of the operation
     *
     * @param value1
     */
    public void setValue1(Double value1) {
        this.value1 = value1;
    }

    /**
     * Getter for the value of the operation.
     * For operations where two values are required to perform the operation i.e. ADD.
     *
     * @return
     */
    public Double getValue2() {
        return value2;
    }

    /**
     * Setter for the value of the operation.
     * For operations where two values are required to perform the operation i.e. ADD.
     *
     * @param value2
     */
    public void setValue2(Double value2) {
        this.value2 = value2;
    }
}

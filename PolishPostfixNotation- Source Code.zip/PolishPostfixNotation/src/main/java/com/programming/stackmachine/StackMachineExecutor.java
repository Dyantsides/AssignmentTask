package com.programming.stackmachine;

import com.programming.stackmachine.OperationType;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;


public class StackMachineExecutor {

    private String userInput;
    private StackMachineImpl stackMachineimpl;
    private Scanner scanner;

    public StackMachineExecutor() {
        this.userInput = null;
        this.stackMachineimpl = null;
        this.scanner = null;
    }

    /**
     * This method get the user input and execute appropriate functionality of the stack.
     */
    public void execute() {
        do {
            try {
                showMenu();
                String input = scanner.nextLine();
                String[] tokens = input.split(ApplicationConstants.SPLIT_STRING_PATTERN);
                final OperationType opType = OperationType.valueOf(tokens[0]);
                switch (opType) {
                    case PUSH:
                        getStackMachineImpInstance().push(Double.parseDouble(tokens[1]));
                        printStackTop();
                        break;
                    case POP:
                        System.out.println(ApplicationConstants.POP_MESSAGE);
                        getStackMachineImpInstance().pop();
                        printStackTop();
                        break;
                    case CLEAR:
                        System.out.println(ApplicationConstants.CLEAR_MESSAGE);
                        getStackMachineImpInstance().clear();
                        printStackTop();
                        break;
                    case ADD:
                        System.out.println(ApplicationConstants.ADD_MESSAGE);
                        getStackMachineImpInstance().add();
                        printStackTop();
                        break;
                    case MUL:
                        System.out.println(ApplicationConstants.MULTIPLY_MESSAGE);
                        getStackMachineImpInstance().multiply();
                        printStackTop();
                        break;
                    case NEG:
                        System.out.println(ApplicationConstants.NEGATE_MESSAGE);
                        getStackMachineImpInstance().negate();
                        printStackTop();
                        break;
                    case INV:
                        System.out.println(ApplicationConstants.INVERT_MESSAGE);
                        getStackMachineImpInstance().invert();
                        printStackTop();
                        break;
                    case UNDO:
                        System.out.println(ApplicationConstants.UNDO_MESSAGE);
                        getStackMachineImpInstance().undo();
                        printStackTop();
                        break;
                    case PRINT:
                        System.out.println(ApplicationConstants.PRINT_MESSAGE);
                        getStackMachineImpInstance().print();
                        break;
                    case QUIT:
                        System.out.println(ApplicationConstants.QUIT_MESSAGE);
                        scanner.close();
                        System.exit(0);
                    default:
                        System.out.println(ApplicationConstants.WRONG_OPTION_SELECTED);
                        showMenu();
                }
            } catch (final Exception ex) {
                System.out.println(ApplicationConstants.WRONG_OPTION_SELECTED);
                //logger.log(ex);
            }
        } while (true);
    }

    /**
     * setter for scanner object. Created for the ease of testing of execute method.
     *
     * @param scanner
     */
    public void setReader(Scanner scanner) {
        this.scanner = scanner;
    }

    /**
     * This method returns the singleton instance of StackMachineImpl class
     *
     * @return
     */
    private StackMachineImpl getStackMachineImpInstance() {
        if (stackMachineimpl == null) {
            stackMachineimpl = new StackMachineImpl();
        }
        return stackMachineimpl;
    }

    /**
     * Method to show the menu to the user every time
     */
    private static void showMenu() {
        System.out.println("Main Menu:");
        System.out.println("------------------");
        System.out.println("Type PUSH to Push the number to the stack");
        System.out.println("Type POP to Pop the number from the stack");
        System.out.println("Type ClEAR to clear the stack");
        System.out.println("Type ADD to add the two numbers from the stack");
        System.out.println("Type MUL to multiply the two numbers from the stack");
        System.out.println("Type NEG to negate the number from the stack");
        System.out.println("Type INV to invert the number from the stack");
        System.out.println("Type UNDO to undo the previous operation on the stack");
        System.out.println("Type PRINT to print the stack");
        System.out.println("Type Quit to exit the application");
        System.out.println("--------------");
        System.out.println("Enter Your choice");
    }

    /**
     * Utility method to print the top of the stack
     */
    private void printStackTop() {
        System.out.println(ApplicationConstants.PRINT_STACKTOP_MESSAGE + getStackMachineImpInstance().getHead().getValue());
    }
}

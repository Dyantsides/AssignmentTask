package com.programming.stackmachine;

/**
 * This class contains all constants being used in the application.
 */
public class ApplicationConstants {

    public static final String SPLIT_STRING_PATTERN = "\\s+";
    public static final String EMPTY_STACK = "Stack is Emtpy";
    public static final String OPERATION_NOT_POSSIBLE_DUE_TO_STACK_SIZE = "Operation is not possible due to Stack size";
    public static final String OPERATION_STACK_EMPTY_STACK = "Operation Stack is Emtpy";
    public static final String ENTER_THE_NUMBER = "Enter the number: ";
    public static final String WRONG_OPTION_SELECTED = "Wrong option selected";
    public static final String POP_MESSAGE = "Poping the stack.";
    public static final String CLEAR_MESSAGE = "Clearing the stack.";
    public static final String ADD_MESSAGE = "Adding two numbers";
    public static final String MULTIPLY_MESSAGE = "Multiplying two numbers";
    public static final String NEGATE_MESSAGE = "Negating the top";
    public static final String UNDO_MESSAGE = "Undoing the previous operation";
    public static final String PRINT_MESSAGE = "Printing the stack";
    public static final String QUIT_MESSAGE = "Shutting down the application";
    public static final String INVERT_MESSAGE = "Inverting the top number";
    public static final String PRINT_STACKTOP_MESSAGE = "Value at the top of stack is: ";

    public static final Double NEGATE_VALUE = -1.0;
    public static final Double INVERT_VALUE = 1.0;
}
